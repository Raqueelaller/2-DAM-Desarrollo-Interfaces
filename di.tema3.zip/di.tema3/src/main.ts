import './style.css'

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
 <a href="https://github.com/Raqueelaller" target="_blank">
      <img src="https://avatars.githubusercontent.com/u/233149401?v=4" class="logo" alt="Vite logo" />
    </a>  

<div >
    <h1>Hola!! mi nombre es Raquel Aller Cerón</h1>
    <p>si pinchas en mi imagen, te lleva directamente a mi poerfil de gitHub</p>
  </div>
`


