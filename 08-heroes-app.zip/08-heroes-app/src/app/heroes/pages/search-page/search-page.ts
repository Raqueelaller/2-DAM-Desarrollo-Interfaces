import { Component } from '@angular/core';

@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.html',
  styles: ``,
  standalone: false
})
export class SearchPageComponent {

}
