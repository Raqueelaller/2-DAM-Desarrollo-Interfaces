import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-page',
  templateUrl: './layout-page.html',
  styles: ``,
  standalone: false
})
export class LayoutPageComponent {

}
