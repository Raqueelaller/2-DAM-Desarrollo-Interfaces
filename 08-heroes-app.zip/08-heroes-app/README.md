# heroes app

## Dev
1. clonar el proyecto
2. ejecutar ```npm install```
3. Levantar el backend ```npm run backend```
4. Ejecutar la app ```npm sart``` o bien ```ng serve -o ``` 
